import { Play } from "lucide-react";
import salonImage from "@assets/generated_images/Norfolk_salon_video_thumbnail_ebf71933.png";
import realtorImage from "@assets/generated_images/Virginia_Beach_realtor_thumbnail_6e0422e0.png";
import restaurantImage from "@assets/generated_images/Restaurant_video_thumbnail_bb1ffecb.png";

const videos = [
  {
    id: 1,
    image: salonImage,
    caption: "Made for a Norfolk Salon",
    size: "large"
  },
  {
    id: 2,
    image: realtorImage,
    caption: "Made for a Virginia Beach Realtor",
    size: "small"
  },
  {
    id: 3,
    image: restaurantImage,
    caption: "Made for a Local Restaurant",
    size: "small"
  }
];

export default function ExampleShowcase() {
  return (
    <section className="py-20 md:py-32 bg-card">
      <div className="max-w-6xl mx-auto px-4 md:px-8">
        <div className="text-center mb-16">
          <h2 className="font-heading font-bold text-4xl md:text-5xl mb-4">
            See What Other Local Businesses Received
          </h2>
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
            Professional video ads that drive real results
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {videos.map((video, index) => (
            <div
              key={video.id}
              className={`relative group cursor-pointer rounded-2xl overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 ${
                index === 0 ? 'md:row-span-2' : ''
              }`}
              data-testid={`video-example-${video.id}`}
            >
              <div className={`relative ${index === 0 ? 'aspect-[9/16]' : 'aspect-[9/16]'}`}>
                <img
                  src={video.image}
                  alt={video.caption}
                  className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-300"
                />
                
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity" />
                
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-16 h-16 rounded-full bg-white/90 backdrop-blur-sm flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Play className="h-8 w-8 text-primary ml-1" fill="currentColor" />
                  </div>
                </div>
                
                <div className="absolute bottom-0 left-0 right-0 p-6">
                  <p className="text-white font-semibold text-lg mb-2">
                    {video.caption}
                  </p>
                  <div className="inline-block px-3 py-1 bg-white/20 backdrop-blur-sm rounded-full">
                    <span className="text-white text-xs font-medium">Owl Vision Consulting</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
