import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { CloudUpload, Globe } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { insertOrderSchema } from "@shared/schema";
import { z } from "zod";

const formSchema = insertOrderSchema.extend({
  packageType: z.string(),
  paymentMethod: z.string(),
  amount: z.string(),
});

type FormData = z.infer<typeof formSchema>;

interface OrderFormProps {
  packageType?: string;
  paymentMethod?: string;
  amount?: string;
  onSubmit: (data: FormData, file: File | null) => void;
}

export default function OrderForm({ 
  packageType = "starter", 
  paymentMethod = "stripe", 
  amount = "$197",
  onSubmit 
}: OrderFormProps) {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  
  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      businessName: "",
      websiteUrl: "",
      socialMediaLink: "",
      businessType: "",
      email: "",
      preferredPlatform: "",
      notes: "",
      logoFileName: "",
      packageType,
      paymentMethod,
      amount,
    },
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      form.setValue("logoFileName", file.name);
    }
  };

  const handleSubmit = (data: FormData) => {
    console.log('Form submitted:', data);
    onSubmit(data, selectedFile);
  };

  return (
    <section id="order-form" className="py-20 md:py-32 bg-card scroll-mt-20">
      <div className="max-w-2xl mx-auto px-4 md:px-8">
        <div className="text-center mb-12">
          <h2 className="font-heading font-bold text-4xl md:text-5xl mb-4">
            Tell Us About Your Business
          </h2>
          <p className="text-lg text-muted-foreground">
            Fill out the form below to get started with your AI video ad
          </p>
        </div>
        
        <Card className="p-8 md:p-12 rounded-2xl">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="businessName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Business Name *</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Acme Inc." 
                        className="rounded-lg p-4 border-2"
                        data-testid="input-business-name"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="websiteUrl"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Website URL *</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <Globe className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                        <Input 
                          placeholder="https://yourwebsite.com" 
                          className="rounded-lg p-4 pl-10 border-2"
                          data-testid="input-website-url"
                          {...field} 
                        />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email Address *</FormLabel>
                    <FormControl>
                      <Input 
                        type="email"
                        placeholder="you@example.com" 
                        className="rounded-lg p-4 border-2"
                        data-testid="input-email"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="businessType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Business Type *</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger className="rounded-lg p-4 border-2" data-testid="select-business-type">
                          <SelectValue placeholder="Select your industry" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="salon">Salon / Beauty</SelectItem>
                        <SelectItem value="realestate">Real Estate</SelectItem>
                        <SelectItem value="restaurant">Restaurant / Food</SelectItem>
                        <SelectItem value="retail">Retail</SelectItem>
                        <SelectItem value="fitness">Fitness / Wellness</SelectItem>
                        <SelectItem value="professional">Professional Services</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="preferredPlatform"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Preferred Platform *</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger className="rounded-lg p-4 border-2" data-testid="select-platform">
                          <SelectValue placeholder="Where will you post?" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="instagram">Instagram</SelectItem>
                        <SelectItem value="facebook">Facebook</SelectItem>
                        <SelectItem value="tiktok">TikTok</SelectItem>
                        <SelectItem value="youtube">YouTube Shorts</SelectItem>
                        <SelectItem value="all">All Platforms</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="socialMediaLink"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Social Media Link (Optional)</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="https://instagram.com/yourbusiness" 
                        className="rounded-lg p-4 border-2"
                        data-testid="input-social-media"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div>
                <FormLabel>Upload Logo (Optional)</FormLabel>
                <div className="mt-2 border-2 border-dashed rounded-lg p-8 text-center hover-elevate cursor-pointer transition-all">
                  <input
                    type="file"
                    onChange={handleFileChange}
                    accept="image/*"
                    className="hidden"
                    id="logo-upload"
                    data-testid="input-file-upload"
                  />
                  <label htmlFor="logo-upload" className="cursor-pointer">
                    <CloudUpload className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                    {selectedFile ? (
                      <p className="text-sm font-medium">{selectedFile.name}</p>
                    ) : (
                      <>
                        <p className="text-sm font-medium mb-1">Click to upload or drag and drop</p>
                        <p className="text-xs text-muted-foreground">PNG, JPG up to 10MB</p>
                      </>
                    )}
                  </label>
                </div>
              </div>
              
              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Notes or Special Requests (Optional)</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Any specific requirements or preferences..." 
                        className="resize-none border-2 text-base rounded-lg min-h-32"
                        data-testid="textarea-notes"
                        {...field}
                        value={field.value || ""}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <Button 
                type="submit" 
                size="lg" 
                className="w-full py-6 text-lg rounded-xl"
                data-testid="button-submit-order"
              >
                Create My Ad
              </Button>
            </form>
          </Form>
        </Card>
      </div>
    </section>
  );
}
