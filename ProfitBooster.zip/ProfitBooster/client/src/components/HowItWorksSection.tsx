import { CloudUpload, Cpu, ArrowDown01, CheckCircle } from "lucide-react";
import { Card } from "@/components/ui/card";

const steps = [
  {
    number: 1,
    icon: CloudUpload,
    title: "You Submit Your Website",
    description: "Paste your business link (and optional logo or images).",
    benefits: ["100% hands-off", "Quick setup", "No technical skills needed"]
  },
  {
    number: 2,
    icon: Cpu,
    title: "AI Builds Your Ad",
    description: "Our advanced tools analyze your website and generate a custom video ad in 24–48 hours.",
    benefits: ["Full ownership", "Professional quality", "Multiple formats"]
  },
  {
    number: 3,
    icon: ArrowDown01,
    title: "You Download & Post",
    description: "Receive your ad in multiple social formats (Instagram, Facebook, TikTok, YouTube Shorts).",
    benefits: ["Fast turnaround", "Ready to post", "All platforms covered"]
  }
];

export default function HowItWorksSection() {
  return (
    <section className="py-20 md:py-32 bg-background">
      <div className="max-w-6xl mx-auto px-4 md:px-8">
        <div className="text-center mb-16">
          <h2 className="font-heading font-bold text-4xl md:text-5xl mb-4">
            How It Works
          </h2>
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
            From website to video ad in three simple steps
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12">
          {steps.map((step, index) => (
            <div key={step.number} className="relative">
              <Card className="p-8 md:p-10 h-full hover-elevate transition-all duration-300">
                <div className="flex flex-col items-center text-center">
                  <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-6">
                    <step.icon className="h-8 w-8 text-primary" />
                  </div>
                  
                  <div className="text-5xl font-bold text-primary/20 mb-4">
                    {step.number}
                  </div>
                  
                  <h3 className="font-heading text-2xl font-semibold mb-4">
                    {step.title}
                  </h3>
                  
                  <p className="text-lg text-muted-foreground leading-relaxed mb-6">
                    {step.description}
                  </p>
                  
                  <div className="space-y-2 mt-auto">
                    {step.benefits.map((benefit) => (
                      <div key={benefit} className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-primary flex-shrink-0" />
                        <span>{benefit}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </Card>
              
              {index < steps.length - 1 && (
                <div className="hidden md:block absolute top-1/2 -right-6 transform -translate-y-1/2 text-primary/30">
                  <ArrowRight className="h-8 w-8" />
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function ArrowRight({ className }: { className?: string }) {
  return (
    <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
    </svg>
  );
}
