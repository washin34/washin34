import { Check, Sparkles, Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { SiStripe, SiPaypal } from "react-icons/si";

interface PricingTier {
  name: string;
  price: string;
  period: string;
  description: string;
  features: string[];
  popular?: boolean;
  priceId: string;
}

const pricingTiers: PricingTier[] = [
  {
    name: "Starter",
    price: "$197",
    period: "one-time",
    description: "Perfect for testing the waters",
    priceId: "starter",
    features: [
      "1 video ad (up to 30 sec)",
      "Caption & hashtags included",
      "1080p export",
      "Ready-to-post formats",
      "2 free revisions",
      "48-hour delivery"
    ]
  },
  {
    name: "Pro",
    price: "$497",
    period: "one-time",
    description: "Most popular for growing businesses",
    priceId: "pro",
    popular: true,
    features: [
      "3 video ads (different hooks & styles)",
      "Branding (logo overlay, color matching)",
      "2 caption + hashtag sets per ad",
      "All social media formats",
      "Unlimited revisions",
      "24-hour priority delivery"
    ]
  },
  {
    name: "Elite",
    price: "$997",
    period: "/month",
    description: "Complete social media management",
    priceId: "elite",
    features: [
      "5 video ads per month",
      "Monthly refresh & new content",
      "Full branding integration",
      "Performance analytics",
      "Dedicated account manager",
      "Same-day delivery",
      "Custom requests accepted"
    ]
  }
];

interface PricingSectionProps {
  onPaymentClick: (tier: string, method: 'stripe' | 'paypal') => void;
}

export default function PricingSection({ onPaymentClick }: PricingSectionProps) {
  return (
    <section id="pricing" className="py-20 md:py-32 bg-background scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        <div className="text-center mb-16">
          <h2 className="font-heading font-bold text-4xl md:text-5xl mb-4">
            Choose Your Package
          </h2>
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
            Professional AI-generated video ads at transparent pricing
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
          {pricingTiers.map((tier) => (
            <Card
              key={tier.name}
              className={`relative p-8 md:p-10 flex flex-col ${
                tier.popular ? 'border-2 border-primary shadow-2xl scale-105' : ''
              }`}
              data-testid={`pricing-card-${tier.name.toLowerCase()}`}
            >
              {tier.popular && (
                <Badge 
                  className="absolute -top-3 left-1/2 transform -translate-x-1/2 px-4 py-1"
                  data-testid="badge-popular"
                >
                  <Sparkles className="h-3 w-3 mr-1" />
                  Most Popular
                </Badge>
              )}
              
              <div className="text-center mb-6">
                <h3 className="font-heading text-xl font-semibold uppercase tracking-wide mb-2">
                  {tier.name}
                </h3>
                <p className="text-sm text-muted-foreground mb-4">{tier.description}</p>
                <div className="flex items-baseline justify-center gap-1">
                  <span className="text-5xl md:text-6xl font-bold">{tier.price}</span>
                  <span className="text-base text-muted-foreground">{tier.period}</span>
                </div>
              </div>
              
              <div className="space-y-3 mb-8 flex-grow">
                {tier.features.map((feature) => (
                  <div key={feature} className="flex items-start gap-3">
                    <Check className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                    <span className="text-base">{feature}</span>
                  </div>
                ))}
              </div>
              
              <div className="space-y-3">
                <Button
                  size="lg"
                  className="w-full rounded-xl gap-2"
                  variant={tier.popular ? "default" : "secondary"}
                  onClick={() => onPaymentClick(tier.priceId, 'stripe')}
                  data-testid={`button-stripe-${tier.name.toLowerCase()}`}
                >
                  <Lock className="h-4 w-4" />
                  Pay Securely with Card
                  <SiStripe className="h-5 w-5 ml-auto" />
                </Button>
                
                <Button
                  size="lg"
                  variant="outline"
                  className="w-full rounded-xl gap-2"
                  onClick={() => onPaymentClick(tier.priceId, 'paypal')}
                  data-testid={`button-paypal-${tier.name.toLowerCase()}`}
                >
                  <Lock className="h-4 w-4" />
                  Checkout via PayPal
                  <SiPaypal className="h-5 w-5 ml-auto text-[#0070ba]" />
                </Button>
              </div>
            </Card>
          ))}
        </div>
        
        <div className="mt-12 text-center">
          <p className="text-sm text-muted-foreground flex items-center justify-center gap-2">
            <Lock className="h-4 w-4" />
            Secure payments powered by Stripe and PayPal
          </p>
        </div>
      </div>
    </section>
  );
}
