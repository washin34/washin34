import { Star, Shield } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const testimonials = [
  {
    id: 1,
    quote: "The AI ad brought in 40% more appointments in the first week. Absolutely worth every penny!",
    author: "Sarah M.",
    business: "Salon Owner, Norfolk",
    rating: 5
  },
  {
    id: 2,
    quote: "Professional quality without the professional price tag. Got 3 listing inquiries from the first ad.",
    author: "Mike R.",
    business: "Realtor, Virginia Beach",
    rating: 5
  },
  {
    id: 3,
    quote: "Fast turnaround and the video perfectly captured our restaurant's vibe. Customers love it!",
    author: "Lisa T.",
    business: "Restaurant Owner",
    rating: 5
  }
];

export default function SocialProofSection() {
  return (
    <section className="py-20 md:py-32 bg-background">
      <div className="max-w-6xl mx-auto px-4 md:px-8">
        <div className="text-center mb-16">
          <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto">
            Hundreds of small businesses trust Owl Vision Consulting to bring their brand to life through smart AI video ads.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          <div className="space-y-6">
            {testimonials.slice(0, 2).map((testimonial) => (
              <Card key={testimonial.id} className="p-6 rounded-xl" data-testid={`testimonial-${testimonial.id}`}>
                <div className="flex gap-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 text-yellow-500 fill-yellow-500" />
                  ))}
                </div>
                <p className="text-lg italic mb-4 leading-relaxed">
                  "{testimonial.quote}"
                </p>
                <div>
                  <p className="font-semibold">{testimonial.author}</p>
                  <p className="text-sm text-muted-foreground">{testimonial.business}</p>
                </div>
              </Card>
            ))}
          </div>
          
          <div className="flex flex-col justify-center">
            <Card key={testimonials[2].id} className="p-6 rounded-xl mb-8" data-testid={`testimonial-${testimonials[2].id}`}>
              <div className="flex gap-1 mb-4">
                {[...Array(testimonials[2].rating)].map((_, i) => (
                  <Star key={i} className="h-5 w-5 text-yellow-500 fill-yellow-500" />
                ))}
              </div>
              <p className="text-lg italic mb-4 leading-relaxed">
                "{testimonials[2].quote}"
              </p>
              <div>
                <p className="font-semibold">{testimonials[2].author}</p>
                <p className="text-sm text-muted-foreground">{testimonials[2].business}</p>
              </div>
            </Card>
            
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-primary/10 mb-6">
                <Shield className="h-12 w-12 text-primary" />
              </div>
              <h3 className="font-heading text-2xl font-bold mb-4">
                100% Satisfaction Guarantee
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                If you're not satisfied, we'll re-edit your ad or refund 100% within 7 days — no questions asked.
              </p>
              <Badge variant="secondary" className="mt-4">
                Risk-Free Promise
              </Badge>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
