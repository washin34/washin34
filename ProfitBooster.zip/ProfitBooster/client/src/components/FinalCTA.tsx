import { Video } from "lucide-react";
import { Button } from "@/components/ui/button";

interface FinalCTAProps {
  onCtaClick: () => void;
}

export default function FinalCTA({ onCtaClick }: FinalCTAProps) {
  return (
    <section className="py-20 md:py-32 bg-gradient-to-br from-primary via-primary/90 to-primary/80 text-primary-foreground">
      <div className="max-w-4xl mx-auto px-4 md:px-8 text-center">
        <Video className="h-16 w-16 mx-auto mb-6 opacity-90" />
        <h2 className="font-heading font-bold text-4xl md:text-5xl mb-6">
          Ready to See What Your Website Looks Like as a Video Ad?
        </h2>
        <p className="text-xl md:text-2xl mb-8 opacity-90">
          Click below to get started instantly. No commitment required.
        </p>
        <Button 
          size="lg" 
          variant="secondary"
          className="px-12 py-6 text-lg font-semibold rounded-xl shadow-2xl hover:scale-105 transition-transform"
          onClick={onCtaClick}
          data-testid="button-final-cta"
        >
          Create My AI Ad Now
        </Button>
        <p className="mt-8 text-sm opacity-75">
          Join hundreds of satisfied businesses • 48-hour delivery • 100% satisfaction guarantee
        </p>
      </div>
    </section>
  );
}
