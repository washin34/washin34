import PricingSection from '../PricingSection';

export default function PricingSectionExample() {
  return (
    <PricingSection 
      onPaymentClick={(tier, method) => console.log(`Payment: ${tier} via ${method}`)} 
    />
  );
}
