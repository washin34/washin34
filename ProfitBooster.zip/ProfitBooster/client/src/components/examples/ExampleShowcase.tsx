import ExampleShowcase from '../ExampleShowcase';

export default function ExampleShowcaseExample() {
  return <ExampleShowcase />;
}
