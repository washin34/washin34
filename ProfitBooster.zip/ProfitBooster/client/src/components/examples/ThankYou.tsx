import ThankYou from '../../pages/ThankYou';
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "../../lib/queryClient";

export default function ThankYouExample() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThankYou />
    </QueryClientProvider>
  );
}
