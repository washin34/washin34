import OrderForm from '../OrderForm';

export default function OrderFormExample() {
  return (
    <OrderForm 
      onSubmit={(data, file) => console.log('Order submitted:', data, file)} 
    />
  );
}
