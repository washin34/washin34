import Header from '../Header';

export default function HeaderExample() {
  return (
    <Header 
      onGetStarted={() => console.log('Get Started clicked')} 
    />
  );
}
