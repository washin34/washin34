import { Button } from "@/components/ui/button";

interface HeaderProps {
  onGetStarted: () => void;
}

export default function Header({ onGetStarted }: HeaderProps) {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-lg border-b transition-all">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="font-heading text-xl font-bold">
            Owl Vision Consulting
          </div>
          
          <Button 
            variant="ghost" 
            onClick={onGetStarted}
            data-testid="button-header-cta"
          >
            Get Started
          </Button>
        </div>
      </div>
    </header>
  );
}
