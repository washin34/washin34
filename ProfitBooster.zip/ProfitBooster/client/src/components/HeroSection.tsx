import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import heroBackground from "@assets/generated_images/AI_tech_hero_background_bbdc1651.png";

interface HeroSectionProps {
  onCtaClick: () => void;
}

export default function HeroSection({ onCtaClick }: HeroSectionProps) {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${heroBackground})` }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/50 to-background/90" />
      
      <div className="relative z-10 max-w-6xl mx-auto px-4 md:px-8 py-20 text-center">
        <h1 className="font-heading font-bold text-5xl md:text-6xl lg:text-7xl tracking-tight text-white mb-6">
          Instantly Turn Your Website into a High-Converting Social Media Ad
        </h1>
        <p className="text-xl md:text-2xl text-white/90 max-w-3xl mx-auto mb-4 leading-relaxed">
          Paste your business website below and get a ready-to-post, professional video ad that brings your brand to life.
        </p>
        <p className="text-lg md:text-xl text-white/80 max-w-2xl mx-auto mb-12">
          No meetings. No phone calls. Just results.
        </p>
        
        <Button 
          size="lg" 
          className="px-8 py-6 text-lg font-semibold rounded-xl shadow-2xl hover:scale-105 transition-transform"
          onClick={onCtaClick}
          data-testid="button-hero-cta"
        >
          Get My AI Ad Now
          <ArrowRight className="ml-2 h-5 w-5" />
        </Button>
      </div>
    </section>
  );
}
