import { useState } from "react";
import { useLocation } from "wouter";
import Header from "@/components/Header";
import HeroSection from "@/components/HeroSection";
import HowItWorksSection from "@/components/HowItWorksSection";
import ExampleShowcase from "@/components/ExampleShowcase";
import PricingSection from "@/components/PricingSection";
import OrderForm from "@/components/OrderForm";
import SocialProofSection from "@/components/SocialProofSection";
import FinalCTA from "@/components/FinalCTA";
import Checkout from "@/pages/Checkout";
import PayPalButton from "@/components/PayPalButton";
import { useToast } from "@/hooks/use-toast";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import type { InsertOrder } from "@shared/schema";

type FormData = InsertOrder;

export default function Home() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [selectedPackage, setSelectedPackage] = useState<{
    packageType: string;
    paymentMethod: string;
    amount: string;
    numericAmount: number;
  } | null>(null);
  const [showCheckout, setShowCheckout] = useState(false);
  const [showPayPal, setShowPayPal] = useState(false);
  const [pendingOrderData, setPendingOrderData] = useState<{ data: FormData; file: File | null } | null>(null);

  const scrollToPricing = () => {
    const pricingSection = document.getElementById('pricing');
    if (pricingSection) {
      pricingSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handlePaymentClick = (tier: string, method: 'stripe' | 'paypal') => {
    // Map tier names to amounts
    const amounts: Record<string, { display: string; numeric: number }> = {
      starter: { display: '$197', numeric: 197 },
      pro: { display: '$497', numeric: 497 },
      elite: { display: '$997', numeric: 997 }
    };

    const packageData = {
      packageType: tier,
      paymentMethod: method,
      amount: amounts[tier]?.display || '$197',
      numericAmount: amounts[tier]?.numeric || 197
    };

    setSelectedPackage(packageData);

    const orderFormSection = document.getElementById('order-form');
    if (orderFormSection) {
      orderFormSection.scrollIntoView({ behavior: 'smooth' });
    }

    toast({
      title: "Payment method selected",
      description: `You selected ${tier} package with ${method}. Please fill out the form below.`,
    });
  };

  const handleOrderSubmit = async (data: FormData, file: File | null) => {
    console.log('Order data collected:', data);
    
    setPendingOrderData({ data, file });
    
    if (data.paymentMethod === 'stripe') {
      // For Stripe, show checkout page
      setShowCheckout(true);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      // For PayPal, show PayPal button
      setShowPayPal(true);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const submitOrder = async (data: FormData, file: File | null) => {
    try {
      const formData = new FormData();
      
      // Append all form fields
      Object.entries(data).forEach(([key, value]) => {
        if (value !== null && value !== undefined) {
          formData.append(key, value.toString());
        }
      });

      // Append logo file if present
      if (file) {
        formData.append('logo', file);
      }

      const response = await fetch('/api/orders', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        throw new Error('Failed to submit order');
      }

      const order = await response.json();
      console.log('Order created:', order);

      toast({
        title: "Order received!",
        description: "Redirecting to confirmation page...",
      });

      setTimeout(() => {
        setLocation('/thank-you');
      }, 1000);
    } catch (error) {
      console.error('Error submitting order:', error);
      toast({
        title: "Error",
        description: "Failed to submit order. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handlePaymentSuccess = async () => {
    if (pendingOrderData) {
      await submitOrder(pendingOrderData.data, pendingOrderData.file);
    }
  };

  const handlePayPalSuccess = async (orderId: string) => {
    console.log('PayPal payment successful, order ID:', orderId);
    if (pendingOrderData) {
      await submitOrder(pendingOrderData.data, pendingOrderData.file);
    }
  };

  const handlePayPalError = (error: any) => {
    console.error('PayPal error:', error);
    toast({
      title: "Payment Failed",
      description: "PayPal payment was not completed. Please try again.",
      variant: "destructive",
    });
  };

  if (showCheckout && selectedPackage) {
    return (
      <Checkout
        amount={selectedPackage.numericAmount}
        packageName={`${selectedPackage.packageType.charAt(0).toUpperCase() + selectedPackage.packageType.slice(1)} Package`}
        onSuccess={handlePaymentSuccess}
      />
    );
  }

  if (showPayPal && selectedPackage) {
    return (
      <div className="min-h-screen bg-background py-20 px-4">
        <div className="max-w-2xl mx-auto">
          <Button
            variant="ghost"
            className="mb-6"
            onClick={() => {
              setShowPayPal(false);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            data-testid="button-back"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>

          <Card className="p-8 md:p-12 rounded-2xl">
            <div className="mb-8">
              <h1 className="font-heading font-bold text-3xl md:text-4xl mb-2">
                Complete Your Payment
              </h1>
              <p className="text-muted-foreground">
                {selectedPackage.packageType.charAt(0).toUpperCase() + selectedPackage.packageType.slice(1)} Package - {selectedPackage.amount}
              </p>
            </div>

            <div className="space-y-6">
              <div className="text-center">
                <p className="text-lg mb-6">Click the button below to complete your payment with PayPal</p>
                <PayPalButton
                  amount={selectedPackage.numericAmount.toString()}
                  currency="USD"
                  intent="CAPTURE"
                  onSuccess={handlePayPalSuccess}
                  onError={handlePayPalError}
                />
              </div>
            </div>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <Header onGetStarted={scrollToPricing} />
      
      <main>
        <HeroSection onCtaClick={scrollToPricing} />
        <HowItWorksSection />
        <ExampleShowcase />
        <PricingSection onPaymentClick={handlePaymentClick} />
        <SocialProofSection />
        {selectedPackage && (
          <OrderForm 
            packageType={selectedPackage.packageType}
            paymentMethod={selectedPackage.paymentMethod}
            amount={selectedPackage.amount}
            onSubmit={handleOrderSubmit}
          />
        )}
        <FinalCTA onCtaClick={scrollToPricing} />
      </main>
      
      <footer className="bg-card border-t py-12">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <div className="text-center text-sm text-muted-foreground">
            <p className="mb-2">© 2025 Owl Vision Consulting. All rights reserved.</p>
            <p>Professional AI-powered video ads for your business.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
