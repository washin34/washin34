import { CheckCircle, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Link } from "wouter";

export default function ThankYou() {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="max-w-2xl w-full p-12 text-center rounded-2xl">
        <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-primary/10 mb-6">
          <CheckCircle className="h-12 w-12 text-primary" />
        </div>
        
        <h1 className="font-heading font-bold text-4xl md:text-5xl mb-4">
          Thank You!
        </h1>
        
        <p className="text-xl text-muted-foreground mb-8 leading-relaxed">
          We're crafting your AI ad now — you'll receive your video within 48 hours.
        </p>
        
        <div className="bg-card rounded-xl p-6 mb-8 space-y-4 text-left">
          <h3 className="font-semibold text-lg mb-4">What happens next?</h3>
          
          <div className="flex gap-4">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">
              1
            </div>
            <div>
              <p className="font-medium">Confirmation Email</p>
              <p className="text-sm text-muted-foreground">You'll receive an email confirmation with your order details within minutes.</p>
            </div>
          </div>
          
          <div className="flex gap-4">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">
              2
            </div>
            <div>
              <p className="font-medium">AI Processing</p>
              <p className="text-sm text-muted-foreground">Our AI tools will analyze your website and create your custom video ad.</p>
            </div>
          </div>
          
          <div className="flex gap-4">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">
              3
            </div>
            <div>
              <p className="font-medium">Delivery</p>
              <p className="text-sm text-muted-foreground">Your completed video ad will be delivered to your email in all requested formats.</p>
            </div>
          </div>
        </div>
        
        <p className="text-sm text-muted-foreground mb-8">
          Questions? Email us at support@owlvisionconsulting.com
        </p>
        
        <Link href="/">
          <Button variant="outline" size="lg" className="gap-2" data-testid="button-back-home">
            <ArrowLeft className="h-4 w-4" />
            Back to Home
          </Button>
        </Link>
      </Card>
    </div>
  );
}
