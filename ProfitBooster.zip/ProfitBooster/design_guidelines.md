# Design Guidelines: Owl Vision Consulting - AI Ad Funnel

## Design Approach

**Reference-Based Approach**: Drawing inspiration from modern SaaS landing pages (Stripe, Linear) combined with creative service showcases (Behance, Dribbble portfolio layouts) and conversion-optimized e-commerce patterns (Shopify). This approach balances professional credibility with creative energy appropriate for an AI video service.

**Core Design Principles**:
- Conversion-first: Every element drives toward payment action
- Trust-building: Professional polish that justifies premium pricing
- Clarity: Complex service made simple through visual hierarchy
- Modern tech aesthetic: Reflects AI/cutting-edge positioning

---

## Typography System

**Font Families** (Google Fonts):
- Primary: Inter (headings, UI elements, pricing)
- Secondary: Space Grotesk (hero headline for impact)
- Body: Inter (all descriptive text)

**Hierarchy**:
- Hero Headline: text-6xl md:text-7xl lg:text-8xl, font-bold, tracking-tight
- Section Headlines: text-4xl md:text-5xl, font-bold
- Subsection Titles: text-2xl md:text-3xl, font-semibold
- Body Text: text-lg, leading-relaxed
- Pricing Amounts: text-5xl md:text-6xl, font-bold
- CTAs: text-lg, font-semibold, tracking-wide

---

## Layout System

**Spacing Primitives**: Use Tailwind units of 4, 8, 12, 16, 20, 24, 32 for consistent rhythm (e.g., p-4, gap-8, mt-12, py-20, space-y-16)

**Container Strategy**:
- Full-width sections: w-full with inner max-w-7xl mx-auto px-4 md:px-8
- Content sections: max-w-6xl mx-auto
- Form containers: max-w-2xl mx-auto
- Text content: max-w-prose for optimal readability

**Vertical Rhythm**:
- Section padding: py-16 md:py-24 lg:py-32
- Between elements: space-y-8 md:space-y-12
- Tight groupings: space-y-4

---

## Component Library & Layout Specifications

### 1. Hero Section (Above Fold)
**Layout**: Single column, centered alignment
- Large hero headline with Space Grotesk
- Subheadline beneath (max-w-3xl mx-auto, text-xl)
- Primary CTA button (large size: px-8 py-4)
- Background: Subtle gradient mesh or abstract tech pattern suggesting AI/automation
- Height: min-h-screen flex items-center (not forced 100vh)

### 2. How It Works Section
**Layout**: Three-column grid on desktop
- Grid: grid-cols-1 md:grid-cols-3, gap-8 md:gap-12
- Each step card:
  - Large numeral badge (text-4xl in circle, w-16 h-16)
  - Step title (text-2xl, font-semibold)
  - Description paragraph (text-lg, leading-relaxed)
  - Icon above numeral from Heroicons (cloud-arrow-up, cpu-chip, arrow-down-tray)
- Visual flow indicators (arrows/dots) between cards on desktop

### 3. Example Showcase Section
**Layout**: Asymmetric video grid for visual interest
- Container: max-w-6xl mx-auto
- 3 video placeholders in masonry-style layout:
  - First video: Larger, 2x height (col-span-2 on desktop)
  - Two smaller videos: Stacked vertically
- Each video card:
  - Aspect ratio 9:16 (mobile video format)
  - Overlay caption: "Made for [Business Type]"
  - Play button icon overlay (centered)
  - Rounded corners (rounded-2xl)
  - Subtle shadow (shadow-xl)
- Watermark: Small "Owl Vision Consulting" badge

### 4. Pricing Section
**Layout**: Three-column cards on desktop, stacked mobile
- Grid: grid-cols-1 md:grid-cols-3, gap-6 md:gap-8
- Each pricing card:
  - Border treatment (border-2, rounded-2xl)
  - Internal padding: p-8 md:p-10
  - Package name (text-xl, font-semibold, uppercase, tracking-wide)
  - Price (text-5xl md:text-6xl, font-bold)
  - "/month" or "one-time" subtext (text-base)
  - Feature list (space-y-3, each with checkmark icon from Heroicons)
  - Two payment buttons stacked (space-y-3):
    - Stripe button (primary styling)
    - PayPal button (secondary styling)
- Middle card (Pro): Elevated styling, "Most Popular" badge at top

**Button Specifications**:
- Large size: w-full px-6 py-3
- Rounded: rounded-xl
- Icons: Heroicons lock-closed for security indicator
- Text: "Pay Securely with Card" / "Checkout via PayPal"

### 5. Order Form Section
**Layout**: Single column, max-w-2xl centered
- Form container: Rounded card (rounded-2xl, p-8 md:p-12)
- Input fields (space-y-6):
  - Business Name (text input, rounded-lg, p-4, border-2)
  - Website URL (URL input with globe icon prefix)
  - Logo Upload (file input with drag-drop zone, border-dashed, p-8)
  - Platform dropdown (select with chevron icon)
  - Notes textarea (min-h-32)
- All inputs: Large touch targets (min-h-12), consistent rounded-lg
- Submit button: Full width, large (py-4), rounded-xl
- Helper text: text-sm beneath inputs where needed

### 6. Social Proof Section
**Layout**: Two-column split on desktop
- Left: Testimonial carousel/grid
  - 2 visible testimonials (grid-cols-1 md:grid-cols-2)
  - Each testimonial card:
    - Quote text (text-lg, italic)
    - Rating stars (5 stars, from Heroicons)
    - Attribution (name, business type, text-sm)
    - Rounded card (rounded-xl, p-6)
- Right: Guarantee badge
  - Large circular badge with shield icon
  - "100% Satisfaction Guarantee" text
  - Supporting copy beneath

### 7. Final CTA Section
**Layout**: Centered, full-width background treatment
- Headline (text-4xl md:text-5xl, font-bold)
- Supporting text (max-w-2xl mx-auto)
- Large CTA button (px-12 py-5)
- Smooth scroll behavior to pricing section

### 8. Sticky Footer CTA (Optional Implementation)
**Layout**: Fixed bottom on scroll
- Appears after scrolling past hero
- Horizontal flex layout
- CTA text + button (compact version)
- Semi-transparent backdrop blur

---

## Navigation

**Header**: Minimal, transparent over hero
- Logo (left): Simple text or icon, h-8
- CTA button (right): "Get Started" ghost button
- Sticky on scroll with subtle shadow

---

## Images & Visual Assets

**Images Required**:

1. **Hero Background**: Abstract AI/tech visualization or gradient mesh (full-width, subtle, non-distracting)
2. **Video Thumbnails**: 3 placeholder video frames showing different business types (salon, realtor, restaurant) - aspect ratio 9:16, professional quality mockups
3. **Logo/Brand Mark**: Owl Vision Consulting brand mark for header

**Image Treatment**:
- Hero: Overlay with semi-transparent gradient for text readability
- Video thumbnails: Slight grayscale until hover, play icon overlay
- All images: Optimized WebP format, lazy loading

**Icons**: Heroicons library via CDN
- Use: check-circle (features), arrow-right (CTAs), play (videos), lock-closed (security), cloud-arrow-up (upload)

---

## Interactive Elements

**Buttons**:
- Primary CTA: Large, rounded-xl, px-8 py-4, font-semibold, shadow-lg
- Secondary: Outlined, same size, transparent with border
- Payment buttons: Branded (Stripe/PayPal logos integrated)
- All buttons: Smooth scale transform on hover (scale-105)

**Form Interactions**:
- Focus states: Border highlight, subtle shadow increase
- File upload: Drag-over state changes border style
- Validation: Inline error messages (text-sm, with alert icon)

**Scroll Behavior**:
- Smooth scroll to anchors
- Intersection observer for fade-in animations on sections (opacity + translateY)
- Parallax effect on hero (subtle, performance-conscious)

---

## Conversion Optimization Features

1. **Trust Indicators Throughout**:
   - Security badges near payment buttons
   - "No meetings, no calls" reassurance
   - Fast turnaround timestamps
   - Money-back guarantee prominently displayed

2. **Urgency Elements**:
   - "48-hour delivery" emphasized
   - Limited availability messaging (subtle)

3. **Social Proof Placement**:
   - After pricing section
   - Micro-testimonials near CTAs

4. **Progressive Disclosure**:
   - Show pricing before form
   - Reveal form after payment intent
   - Minimize cognitive load at each step

This design creates a professional, conversion-focused funnel that builds trust while maintaining the energy and innovation expected from an AI service provider.