import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const orders = pgTable("orders", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  businessName: text("business_name").notNull(),
  websiteUrl: text("website_url").notNull(),
  socialMediaLink: text("social_media_link"),
  businessType: text("business_type").notNull(),
  email: text("email").notNull(),
  preferredPlatform: text("preferred_platform").notNull(),
  notes: text("notes"),
  logoFileName: text("logo_file_name"),
  packageType: text("package_type").notNull(),
  paymentMethod: text("payment_method").notNull(),
  amount: text("amount").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertOrderSchema = createInsertSchema(orders).omit({
  id: true,
  createdAt: true,
}).extend({
  email: z.string().email("Please enter a valid email address"),
  websiteUrl: z.string().url("Please enter a valid website URL"),
  socialMediaLink: z.string().url("Please enter a valid URL").optional().or(z.literal("")),
});

export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type Order = typeof orders.$inferSelect;
